<?php
include "config.php";
echo "<br/>";

echo "<a href='index.php?root=ajouter'>ajouter</a><br/>";
echo "<a href='index.php?root=modifier'>modifier</a><br/>";
echo "<a href='index.php?root=supprimer'>supprimer</a><br/>";

if(isset($_GET['root']) == true){
   if($_GET['root'] == 'ajouter'){
     $link->query("INSERT INTO tp.utilisateur (idutilisateur, nom, prenom, date) VALUES (null,'Bryant', 'Kobe', '2021/12/17')");
   }
   if($_GET['root'] == 'modifier'){
    $link->query ("UPDATE tp.utilisateur SET nom='Jordan jr' WHERE utilisateur.idutilisateur=7");
   }
   if($_GET['root'] == 'supprimer'){
    $link->query("DELETE FROM tp.utilisateur WHERE utilisateur.idutilisateur=10");
   }
}
// ajouter//$link->query("INSERT INTO tp.utilisateur (idutilisateur, nom, prenom, date) VALUES (null,'Jordan', 'Michael', '2021/12/17')");
// modifier//$link->query ("UPDATE tp.utilisateur SET nom='Moore' WHERE utilisateur.idutilisateur=7");
// supprimer// $link->query("DELETE FROM tp.utilisateur WHERE utilisateur.idutilisateur=8");
$result=$link->query("SELECT * FROM tp.utilisateur");
// var_dump ($result);
while ($row=$result->fetch_array()){
    echo "<br/> Id : ".$row['idutilisateur'];
    echo "<br/> Nom : ".$row['nom'];
    echo "<br/> Prénom : ".$row['prenom'];
    echo "<br/> Date d'inscription : ".$row['date'];
    echo "<hr/>"; 
}
// var_dump($row);



?>