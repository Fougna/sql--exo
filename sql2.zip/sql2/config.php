<?php
$server="localhost";
$user="root";
$password="";
$db="tp";
$link=new mysqli($server, $user, $password, $db,3308);
// var_dump($link);
if ($link->connect_error != null){
  die  ("connexion échouée".$link->connect_error);
}
else{
    echo "connexion réussie";
}
?>